import customtkinter as ctk
import json


OPENED_TASK_WINDOWS = {}


class TaskDetailsWindow:

    def __init__(
        self,
        parent,
        task,
        store=None,
        on_refresh=None
    ):

        self.parent = parent
        self.task = task
        self.task_id = task.id

        self.store = store
        self.on_refresh = on_refresh

        self.build()

    # =====================================================
    # BUILD
    # =====================================================

    def build(self):

        self.win = ctk.CTkToplevel(
            self.parent
        )

        self.win.title(
            self.task.title
        )

        self.win.geometry(
            "700x820"
        )

        self.win.lift()
        self.win.focus_force()

        self.win.protocol(
            "WM_DELETE_WINDOW",
            self.on_close
        )

        OPENED_TASK_WINDOWS[
            self.task_id
        ] = self

        self.root = ctk.CTkScrollableFrame(
            self.win
        )

        self.root.pack(
            fill="both",
            expand=True,
            padx=18,
            pady=18
        )

        self.render_content()

    # =====================================================
    # RENDER
    # =====================================================

    def render_content(self):

        for child in self.root.winfo_children():
            child.destroy()

        root = self.root

        # =================================================
        # TITLE
        # =================================================

        ctk.CTkLabel(
            root,
            text=self.task.title,
            font=ctk.CTkFont(
                size=32,
                weight="bold"
            ),
            anchor="w"
        ).pack(
            fill="x",
            pady=(0, 10)
        )

        # =================================================
        # DATE
        # =================================================

        dt = self.task.date

        if getattr(
            self.task,
            "time_start",
            None
        ):

            dt += (
                f"  {self.task.time_start}"
            )

            if getattr(
                self.task,
                "time_end",
                None
            ):

                dt += (
                    f" - {self.task.time_end}"
                )

        ctk.CTkLabel(
            root,
            text=dt,
            text_color="#9CA3AF",
            font=ctk.CTkFont(
                size=18
            )
        ).pack(
            anchor="w",
            pady=(0, 24)
        )

        # =================================================
        # DESCRIPTION
        # =================================================

        ctk.CTkLabel(
            root,
            text="Описание",
            font=ctk.CTkFont(
                size=20,
                weight="bold"
            )
        ).pack(
            anchor="w",
            pady=(0, 10)
        )

        self.desc_box = ctk.CTkTextbox(
            root,
            height=220,
            corner_radius=18
        )

        self.desc_box.pack(
            fill="x",
            pady=(0, 24)
        )

        self.desc_box.insert(
            "1.0",
            getattr(
                self.task,
                "description",
                ""
            ) or ""
        )

        # =================================================
        # SUBTASKS
        # =================================================

        self.subtask_vars = []

        try:

            subtasks = json.loads(
                self.task.subtasks_json or "[]"
            )

        except Exception:

            subtasks = []

        ctk.CTkLabel(
            root,
            text="Подзадачи",
            font=ctk.CTkFont(
                size=20,
                weight="bold"
            )
        ).pack(
            anchor="w",
            pady=(0, 12)
        )

        subt_frame = ctk.CTkFrame(
            root,
            corner_radius=18
        )

        subt_frame.pack(
            fill="x",
            pady=(0, 24)
        )

        if not subtasks:

            ctk.CTkLabel(
                subt_frame,
                text="Нет подзадач"
            ).pack(
                anchor="w",
                padx=16,
                pady=16
            )

        for sub in subtasks:

            row = ctk.CTkFrame(
                subt_frame,
                fg_color="transparent"
            )

            row.pack(
                fill="x",
                padx=14,
                pady=8
            )

            var = ctk.IntVar(
                value=int(
                    sub.get(
                        "done",
                        0
                    )
                )
            )

            cb = ctk.CTkCheckBox(
                row,
                text=sub.get(
                    "text",
                    ""
                ),
                variable=var
            )

            cb.pack(
                anchor="w"
            )

            self.subtask_vars.append(
                (
                    var,
                    sub
                )
            )

        # =================================================
        # TAG
        # =================================================

        if getattr(
            self.task,
            "tag",
            None
        ):

            ctk.CTkLabel(
                root,
                text=self.task.tag,
                height=36,
                corner_radius=18,
                fg_color="#2563EB",
                padx=16
            ).pack(
                anchor="w",
                pady=(0, 24)
            )

        # =================================================
        # SAVE BUTTON
        # =================================================

        ctk.CTkButton(
            root,
            text="Сохранить изменения",
            height=52,
            font=ctk.CTkFont(
                size=17,
                weight="bold"
            ),
            command=self.save_changes
        ).pack(
            fill="x",
            pady=(10, 20)
        )

    # =====================================================
    # REFRESH CONTENT
    # =====================================================

    def refresh_content(self):

        fresh = self.store.get_task(
            self.task_id
        )

        if not fresh:
            return

        self.task = fresh

        self.render_content()

    # =====================================================
    # CLOSE
    # =====================================================

    def on_close(self):

        try:

            if (
                self.task_id
                in OPENED_TASK_WINDOWS
            ):

                del OPENED_TASK_WINDOWS[
                    self.task_id
                ]

        except Exception:
            pass

        try:
            self.win.destroy()
        except Exception:
            pass

    # =====================================================
    # SAVE
    # =====================================================

    def save_changes(self):

        description = self.desc_box.get(
            "1.0",
            "end"
        ).strip()

        subtasks = []

        for var, sub in self.subtask_vars:

            subtasks.append({
                "text": sub.get(
                    "text",
                    ""
                ),
                "done": int(
                    var.get()
                )
            })

        subtasks_json = json.dumps(
            subtasks,
            ensure_ascii=False
        )

        try:

            self.store.update_task(
                self.task.id,
                title=self.task.title,
                date=self.task.date,
                time_start=self.task.time_start,
                time_end=self.task.time_end,
                tag=self.task.tag,
                description=description,
                subtasks_json=subtasks_json,
                remind_offsets_json=self.task.remind_offsets_json
            )

        except Exception as e:

            print(e)
            return

        # ==========================================
        # REFRESH MAIN UI
        # ==========================================

        try:

            if self.on_refresh:
                self.on_refresh()

        except Exception as e:

            print(e)

        # ==========================================
        # REFRESH ALL OPEN WINDOWS
        # ==========================================

        current_windows = []

        for task_id, window in list(
            OPENED_TASK_WINDOWS.items()
        ):

            if task_id == self.task_id:

                current_windows.append(
                    window
                )

        for window in current_windows:

            try:

                if (
                    hasattr(window, "win")
                    and window.win.winfo_exists()
                ):

                    window.refresh_content()

            except Exception as e:

                print(e)